<?php
class Index extends CI_Controller
{
	function __construct()
	{
		
		parent::__construct();
		
		$this->load->helper('form');
		
		$this->load->library('form_validation');
		$this->load->model('user_model');
		$this->load->helper('url');
	}
	
	public function user()
	{
		//print_r('innn');exit;
		$error = "";
		if(!empty($this->input->post()))
		{
			$pval = $this->input->post();
			
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'gif|JPG|png';
			
			$this->load->library('upload',$config);
			print_r($this->upload->do_upload('photo'));exit;
			if(!empty($this->upload->do_upload('photo')))
			{ 
				$error = array('error'=> $this->upload->display_errors());
			}
			$this->upload->initialize($config);
			//$this->user_model->save($pval);
			
		}
		
		$this->load->view('manage',$error);
	}
	
	public function view()
	{
		 
		 
		$fetchLoginDetail = $this->user_model->fetchUserData();
			 
			 
		$data['fetchDetails'] = $fetchLoginDetail;
		$this->load->view('list',$data);
	}
	
	
}