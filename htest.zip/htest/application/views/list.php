<table border="1">
<?php
	foreach($fetchDetails as $k => $v)
	{ 
?>
<tr>
<td>
	<?php
		echo $v['id'];
	?>
</td>
<td>
	<?php
		echo $v['name'];
	?>
</td>
<td>
<a href="<?php echo base_url();?>Crud/edit/id/<?php echo $v['id']?>">Edit</a>
</td>
</tr>
<?php
	}
?>
</table>