<?php
	$formAttr = array('id'=>'uform','name'=>'uform');
	echo form_open_multipart(base_url().'index/user',$formAttr);
	
?>
Name
<?php
	$name = array('id'=>'ename','name'=>'ename');
	echo form_input($name);
	
?>
<br>
<br>
	<input type="file" name="photo" value="photo">
<br>
<br>
<?php
	$save = array('id'=>'save','name'=>'save','value'=>'save');
	echo form_submit($save);

	echo form_close();
?>