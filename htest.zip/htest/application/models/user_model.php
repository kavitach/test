<?php
class user_model extends CI_Model
{
	function fetchUserData($data = array())
	{
		$this->db->select();
		$query = $this->db->get('users');
		
		if(!empty($query->num_rows()))
		{
			return $query->result_array();
		}
	}
	
	function save($data = array())
	{
		$dataArr = array('name'=>$data['ename']);
		$this->db->insert('users',$dataArr);
	}
}
?>